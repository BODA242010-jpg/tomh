# طُمُوح | TMoh — الإصدار 3.2

## الملفات
index.html, app.js, style.css, manifest.json, sw.js, icon.svg, icon-192.png, icon-512.png  ← ترفع على GitHub Pages
worker.js  ← يُنشر على Cloudflare Workers (وسيط المساعد الذكي)
supabase/schema.sql  ← مخطط قاعدة البيانات وسياسات RLS (لم يُربط بالواجهة بعد)

## التشغيل
افتح index.html، أو: python -m http.server 8000 ثم http://localhost:8000 (الـ Service Worker يحتاج http وليس file://).

## المساعد الذكي (Cloudflare Worker + Gemini)
اتبع الخطوات في أول worker.js. نقاط مهمة:
1. المفتاح GEMINI_API_KEY يُحفظ كـ Secret في Cloudflare فقط.
2. ALLOWED_ORIGIN = رابط موقعك على GitHub Pages.
3. الـ Worker يرفض الطلبات ما لم تربط Rate Limiting binding باسم RL و/أو KV باسم KV.
4. ضع رابط الـ Worker في CONFIG.AI_URL أعلى app.js. صفحة المساعد تعرض حالة الخدمة (متصل / غير متاحة).
الحد هنا لكل عنوان IP. الحد لكل حساب يحتاج ربط Supabase.

## قاعدة البيانات (Supabase)
1. أنشئ مشروعًا، ثم الصق supabase/schema.sql في SQL Editor وشغّله.
2. بعد تسجيل حسابك عيّن نفسك مديرًا بالسطر الأخير في الملف.
3. الواجهة الحالية لا تتصل بـ Supabase بعد: البيانات محلية (localStorage + IndexedDB للصور).

## ما يعمل الآن
مؤقت دقيق (لا يحسب وقت إغلاق الصفحة، ويقسم الجلسات عند منتصف الليل) • بنك أخطاء بصور في IndexedDB • تراكمات بخطة حسب وقتك اليومي • نظام اختبارات من بنك أسئلة تضيفه أنت (اختيار من متعدد/صح وخطأ، مؤقت، تصحيح تلقائي، سجل، نقاط ضعف) • نسخ احتياطي كامل بإصدار وفحص بنية • تقرير أداء للطباعة/PDF • تذكير بالمهام • PWA يعمل بدون إنترنت.

## ما لا يعمل بعد
حسابات Supabase والمزامنة ولوحة الإدارة • دروس المناهج الرسمية (تُستورد من ملف JSON) • أسئلة رسمية جاهزة • ملفات PDF للدروس.
